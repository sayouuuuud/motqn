'use client'

import { useState } from 'react'
import { LuCheck, LuCopy } from 'react-icons/lu'

import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

interface CopyProps {
  content: string
}

export function Copy({ content }: CopyProps) {
  const [isCopied, setIsCopied] = useState(false)

  async function handleCopy() {
    await navigator.clipboard.writeText(content)
    setIsCopied(true)

    setTimeout(() => {
      setIsCopied(false)
    }, 2000)
  }

  return (
    <Button className="size-8! cursor-pointer" onClick={handleCopy} size="icon" variant="outline">
      <LuCopy
        className={cn(
          'absolute size-3.5! transform transition-opacity duration-300',
          isCopied ? 'scale-90 opacity-0' : 'scale-100 opacity-100'
        )}
      />
      <LuCheck
        className={cn(
          'absolute size-3.5! transform transition-opacity duration-300',
          isCopied ? 'scale-100 opacity-100' : 'scale-90 opacity-0'
        )}
      />
    </Button>
  )
}
