import { useEffect, useState } from 'react'
import { usePathname } from 'next/navigation'
import { LuChevronDown, LuChevronRight } from 'react-icons/lu'

import { Anchor } from '@/components/anchor'
import { Button } from '@/components/ui/button'
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible'
import { SheetClose } from '@/components/ui/sheet'
import { type Paths } from '@/lib/pageroutes'
import { cn } from '@/lib/utils'

function isRoute(item: Paths): item is Extract<Paths, { title: string; href: string }> {
  return 'title' in item && 'href' in item
}

export function SubLink(props: Paths & { level: number; isSheet: boolean }) {
  const path = usePathname()
  const [isOpen, setIsOpen] = useState(true)

  useEffect(() => {
    if (isRoute(props) && props.href && path !== props.href && path.includes(props.href)) {
      Promise.resolve().then(() => setIsOpen(true))
    }
  }, [path, props])

  if (!isRoute(props)) return

  const { title, href, items, noLink, level, isSheet } = props

  const Comp = (
    <Anchor activeClassName="text-primary text-sm font-semibold" href={href}>
      {title}
    </Anchor>
  )

  const titleOrLink = !noLink ? (
    isSheet ? (
      <SheetClose asChild>{Comp}</SheetClose>
    ) : (
      Comp
    )
  ) : (
    <h2 className="font-bold text-primary sm:text-sm">{title}</h2>
  )

  if (!items) {
    return <div className="flex flex-col text-sm">{titleOrLink}</div>
  }

  return (
    <div className="flex w-full flex-col gap-1">
      <Collapsible onOpenChange={setIsOpen} open={isOpen}>
        <div className="mr-3 flex items-center gap-2 text-sm">
          {titleOrLink}
          <CollapsibleTrigger asChild>
            <Button className="ml-auto h-6 w-6" size="icon" variant="link">
              {!isOpen ? (
                <LuChevronRight className="h-[0.9rem] w-[0.9rem]" />
              ) : (
                <LuChevronDown className="h-[0.9rem] w-[0.9rem]" />
              )}
              <span className="sr-only">Toggle</span>
            </Button>
          </CollapsibleTrigger>
        </div>
        <CollapsibleContent className="CollapsibleContent">
          <div
            className={cn(
              'mt-2.5 flex flex-col items-start gap-3 border-l pl-4 text-sm',
              level > 0 && 'ml-1 border-l pl-4'
            )}
          >
            {items?.map((innerLink) => {
              if (!isRoute(innerLink)) {
                return null
              }

              const modifiedItems = {
                ...innerLink,
                href: `${href}${innerLink.href}`,
                level: level + 1,
                isSheet,
              }

              return <SubLink key={modifiedItems.href} {...modifiedItems} />
            })}
          </div>
        </CollapsibleContent>
      </Collapsible>
    </div>
  )
}
